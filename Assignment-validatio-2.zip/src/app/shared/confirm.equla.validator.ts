
import { AbstractControl,FormGroup } from "@angular/forms";


export function EqualValidator(controlName:string , matchingControlName:string)
{
    return(form:FormGroup)=>
    {
        const control=form.controls[controlName];
        const controlmatch=form.controls[matchingControlName];

        if(!control && !controlmatch)
        {
            return null;
        }
        if(controlmatch.errors && !controlmatch.errors.ConfirmEqualValidator )
        {
            return null;
        }
        if(control.value!==controlmatch.value)
        {
            controlmatch.setErrors({ConfirmEqualValidator:true})
            return null;
        }
        else{
             controlmatch.setErrors(null);
             return null;
        }
    }
}