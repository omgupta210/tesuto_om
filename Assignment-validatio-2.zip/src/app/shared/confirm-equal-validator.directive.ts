import { Directive, Input } from '@angular/core';
import { FormGroup, NG_VALIDATORS } from '@angular/forms';
import { EqualValidator } from './confirm.equla.validator';

@Directive({
  selector: '[ConfirmEqualValidator]',
  providers: [{provide:NG_VALIDATORS, useExisting:ConfirmEqualValidatorDirective , multi:true}]
})
export class ConfirmEqualValidatorDirective {

  @Input('ConfirmEqualValidator') ConfirmEqualValidator:string[];
  constructor() {
    this.ConfirmEqualValidator=[];
   }

   public validate(formGroup:FormGroup):null{
    return EqualValidator(this.ConfirmEqualValidator[0],this.ConfirmEqualValidator[1])(formGroup);
   }

}
