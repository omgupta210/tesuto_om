import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { EqualValidator } from '../shared/confirm.equla.validator';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  
  public userform:FormGroup;
  public userdetails:any;
  public isuserformsubmitted:boolean;
  constructor( private formbuilder:FormBuilder) {
    this.userform={} as FormGroup;
    this.userdetails={};
    this.isuserformsubmitted=false;
   }

  ngOnInit(): void {
    this.initialization();
   
  }



  public initialization():void{
      this.userform=this.formbuilder.group({
         email:['',[Validators.required,Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
         name:['',Validators.required],
         address:['',Validators.required],
         city:['',Validators.required],
         pno:['',[Validators.required,Validators.pattern("[0-9 ]{10,13}")]],
         password:['',[Validators.required,Validators.pattern("[0-9a-zA-Z/@/#/$]{6,}")]],
         passwordcheck:['',[Validators.required]]
        
      })
  }

  public submit():void{
    this.isuserformsubmitted=true;
  }
  get userFormContorls()
  {
    return this.userform.controls;
  }

}
