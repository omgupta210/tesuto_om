import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
  public toshow:boolean=false;
  public userform:FormGroup;
  public userdetails:any;
  constructor( private formbuilder:FormBuilder) {
    this.userform={} as FormGroup;
    this.userdetails={}
   }

  ngOnInit(): void {
    this.initialization();
  }
  public display():void{
    this.toshow=true;
 }


  public initialization():void{
      this.userform=this.formbuilder.group({
         email:[''],
         name:[''],
         address:[''],
         city:[''],
         pno:[''],
         password:[''],
      })
  }

}
