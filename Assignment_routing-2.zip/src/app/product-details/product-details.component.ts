import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  public productdetails:Product;

  constructor(private activatedRoute:ActivatedRoute,private route:Router) { 
    this.productdetails={} as Product;
  }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params:any)=>{
      console.log(params);
      this.productdetails.id=params.get("id");
      this.productdetails.name=params.get("name");
      this.productdetails.description=params.get("description");
      this.productdetails.price=params.get("price");
      this.productdetails.img=params.get("img");

    })

  }
  
  public gotoproduct():void{
    this.route.navigate(['/product'])
  }
}
