import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private productlist:Product[];

  constructor() { 
    this.productlist=[];
  }

  public getdata(): Product[] 
  {
      return [
        {   
          "name":"OnePlus Nord CE 2 Lite 5G",
            "price":18999,
            "id":3,
        "description":"6GB RAM, 128GB Storage",
        "img":"https://m.media-amazon.com/images/I/71AvQd3VzqL._SL1500_.jpg"
          },
          {
            "name":"Redmi Note 10T 5G ",
            "price":11999,
            "id":2,
        "description":"Mint Green, 4GB RAM, 64GB Storage)",
        "img":"https://m.media-amazon.com/images/I/81I6652dKDL._SL1500_.jpg"
        
         },
         {
            "name":"realme narzo 50",
            "price":12999,
            "id":5,
        "description":"Speed Black, 4GB RAM+64GB Storage",
        "img":"https://m.media-amazon.com/images/I/61XAfyZcRpL._SL1500_.jpg"
        
         }
       
   

    ]
  }
}
