import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  
   prd1:Product[]=[];
  constructor(private prd:ProductService,private route:Router) {
    
   }

  ngOnInit(): void {
     this.prd1=this.prd.getdata();
  }

  getDetails(product:Product):void
  {
       this.route.navigate(['/product-details',product.id,product.description,product.img,product.price,product.name],{skipLocationChange:true});
  }

  
}
