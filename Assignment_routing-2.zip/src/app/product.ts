export interface Product {
    name:string;
    price:number;
    id:number;
    description:string;
    img:string;
}
