import { FormGroup } from "@angular/forms";

export function MustMatchValidate(controlName:string, matchingControlName:string)
{
    return ( form : FormGroup)=>{

        const control=form.controls[controlName];
        const matchingcontorl=form.controls[matchingControlName];

        if(!control || !matchingcontorl)
          {
            return null;
          }
        if(matchingcontorl.errors && !matchingcontorl.errors['mustMacth'] )
        {
            return null;
        }
        if(control.value !== matchingcontorl.value)
        {
            matchingcontorl.setErrors({mustMatch:true});
            return null;
        }
       
        else{
            matchingcontorl.setErrors(null);
            return null;
        }
    };
}