import { Directive, Input } from '@angular/core';
import { FormGroup, NG_VALIDATORS } from '@angular/forms';
import { MustMatchValidate } from './must.match.Validate';

@Directive({
  selector: '[mustMacth]',
  providers :[{ provide: NG_VALIDATORS,useExisting:MustMatchDirective, multi:true }]
})

export class MustMatchDirective {

  @Input('mustMacth') mustMacth:string[];

  constructor() {
    this.mustMacth=[]
   }

   public validate(formGroup:FormGroup):null{

    return MustMatchValidate(this.mustMacth[0],this.mustMacth[1])(formGroup);
    
   }

}
